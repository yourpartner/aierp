SELECT id, bank_name, account_number, account_name, withdrawal_amount, description
FROM moneytree_transactions 
WHERE id IN ('3ba6fd71-aa48-4a59-85e4-91ae36470757', 'ea34dcd7-31fb-4ca7-9241-31bcd4ea1f2b');

