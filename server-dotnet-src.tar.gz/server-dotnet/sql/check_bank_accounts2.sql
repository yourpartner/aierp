SELECT account_code, name, payload
FROM accounts 
WHERE company_code='JP01' 
AND account_code = '131';

