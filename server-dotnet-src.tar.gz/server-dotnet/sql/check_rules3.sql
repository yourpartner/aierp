SELECT title, action
FROM moneytree_posting_rules 
WHERE company_code='JP01' 
LIMIT 3;

